#include <stdio.h>

int main() {
    /* TODO: print the string "Hello World!" on the terminal */
    return 0;
}

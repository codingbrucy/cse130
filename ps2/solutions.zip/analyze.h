#ifndef __ANALYZE_H
#define __ANALYZE_H

void analyzeURL(char* url,char* host,int* port,char* doc);

#endif
